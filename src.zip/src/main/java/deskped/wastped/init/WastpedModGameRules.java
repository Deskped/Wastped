/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WastpedModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> DO_AUTOSPAWN_IN_WASTE = GameRules.register("doAutospawnInWaste", GameRules.Category.SPAWNING, GameRules.BooleanValue.create(true));
}