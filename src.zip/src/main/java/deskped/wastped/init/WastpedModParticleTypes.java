/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import deskped.wastped.WastpedMod;

public class WastpedModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, WastpedMod.MODID);
	public static final RegistryObject<SimpleParticleType> WIND_PARTICLE = REGISTRY.register("wind_particle", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> ANFIRANOINCODE = REGISTRY.register("anfiranoincode", () -> new SimpleParticleType(false));
}