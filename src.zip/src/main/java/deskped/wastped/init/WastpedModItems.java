/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import deskped.wastped.item.TumaniteCrystalItem;
import deskped.wastped.item.SaltItem;
import deskped.wastped.WastpedMod;

public class WastpedModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WastpedMod.MODID);
	public static final RegistryObject<Item> WASTEGRASS;
	public static final RegistryObject<Item> GATE;
	public static final RegistryObject<Item> SAND_BRICKS;
	public static final RegistryObject<Item> TUMANITE_CRYSTAL;
	public static final RegistryObject<Item> SALT_BLOCK;
	public static final RegistryObject<Item> SALT;
	static {
		WASTEGRASS = block(WastpedModBlocks.WASTEGRASS);
		GATE = block(WastpedModBlocks.GATE, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
		SAND_BRICKS = block(WastpedModBlocks.SAND_BRICKS);
		TUMANITE_CRYSTAL = REGISTRY.register("tumanite_crystal", TumaniteCrystalItem::new);
		SALT_BLOCK = block(WastpedModBlocks.SALT_BLOCK);
		SALT = REGISTRY.register("salt", SaltItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}