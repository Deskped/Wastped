/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import deskped.wastped.potion.ThirstMobEffect;
import deskped.wastped.WastpedMod;

public class WastpedModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, WastpedMod.MODID);
	public static final RegistryObject<MobEffect> THIRST = REGISTRY.register("thirst", () -> new ThirstMobEffect());
}