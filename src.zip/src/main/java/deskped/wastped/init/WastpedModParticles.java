/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.wastped.client.particle.WindParticleParticle;
import deskped.wastped.client.particle.AnfiranoincodeParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WastpedModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(WastpedModParticleTypes.WIND_PARTICLE.get(), WindParticleParticle::provider);
		event.registerSpriteSet(WastpedModParticleTypes.ANFIRANOINCODE.get(), AnfiranoincodeParticle::provider);
	}
}