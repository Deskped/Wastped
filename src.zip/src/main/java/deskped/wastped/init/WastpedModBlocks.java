/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import deskped.wastped.block.WastegrassBlock;
import deskped.wastped.block.SandBricksBlock;
import deskped.wastped.block.SaltBlockBlock;
import deskped.wastped.block.GateBlock;
import deskped.wastped.WastpedMod;

public class WastpedModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, WastpedMod.MODID);
	public static final RegistryObject<Block> WASTEGRASS;
	public static final RegistryObject<Block> GATE;
	public static final RegistryObject<Block> SAND_BRICKS;
	public static final RegistryObject<Block> SALT_BLOCK;
	static {
		WASTEGRASS = REGISTRY.register("wastegrass", WastegrassBlock::new);
		GATE = REGISTRY.register("gate", GateBlock::new);
		SAND_BRICKS = REGISTRY.register("sand_bricks", SandBricksBlock::new);
		SALT_BLOCK = REGISTRY.register("salt_block", SaltBlockBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}