/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.wastped.client.renderer.IndianMaleRenderer;
import deskped.wastped.client.renderer.IndianFemaleRenderer;
import deskped.wastped.client.renderer.AnfiraRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WastpedModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(WastpedModEntities.ANFIRA.get(), AnfiraRenderer::new);
		event.registerEntityRenderer(WastpedModEntities.INDIAN_MALE.get(), IndianMaleRenderer::new);
		event.registerEntityRenderer(WastpedModEntities.INDIAN_FEMALE.get(), IndianFemaleRenderer::new);
	}
}