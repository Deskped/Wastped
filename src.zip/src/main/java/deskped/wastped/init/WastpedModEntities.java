/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.wastped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import deskped.wastped.entity.IndianMaleEntity;
import deskped.wastped.entity.IndianFemaleEntity;
import deskped.wastped.entity.AnfiraEntity;
import deskped.wastped.WastpedMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WastpedModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WastpedMod.MODID);
	public static final RegistryObject<EntityType<AnfiraEntity>> ANFIRA = register("anfira",
			EntityType.Builder.<AnfiraEntity>of(AnfiraEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(33).setUpdateInterval(3).setCustomClientFactory(AnfiraEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<IndianMaleEntity>> INDIAN_MALE = register("indian_male",
			EntityType.Builder.<IndianMaleEntity>of(IndianMaleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(33).setUpdateInterval(3).setCustomClientFactory(IndianMaleEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<IndianFemaleEntity>> INDIAN_FEMALE = register("indian_female",
			EntityType.Builder.<IndianFemaleEntity>of(IndianFemaleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(33).setUpdateInterval(3).setCustomClientFactory(IndianFemaleEntity::new)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			AnfiraEntity.init();
			IndianMaleEntity.init();
			IndianFemaleEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ANFIRA.get(), AnfiraEntity.createAttributes().build());
		event.put(INDIAN_MALE.get(), IndianMaleEntity.createAttributes().build());
		event.put(INDIAN_FEMALE.get(), IndianFemaleEntity.createAttributes().build());
	}
}