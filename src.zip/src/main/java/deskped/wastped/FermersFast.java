package net.deskped.wastped;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;

@Mod.EventBusSubscriber
public class FermersFast {

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        BlockPos pos = event.getPos();
        BlockState state = level.getBlockState(pos);

        if (level.isClientSide) return;
        if (!event.getItemStack().isEmpty()) return;

        if (state.getBlock() instanceof CropBlock crop) {
            Property<?> ageProp = crop.getStateDefinition().getProperty("age");
            if (ageProp instanceof net.minecraft.world.level.block.state.properties.IntegerProperty age) {
                if (state.getValue(age) >= crop.getMaxAge()) {
                    ItemStack seeds = new ItemStack(state.getBlock().asItem());
                    level.destroyBlock(pos, true);
                    level.setBlock(pos, crop.defaultBlockState(), 3);
                    if (!event.getEntity().isCreative()) event.getEntity().getInventory().add(seeds);
                    spawnParticles(level, pos);
                }
            }
        } else if (state.is(Blocks.PUMPKIN) || state.is(Blocks.MELON)) {
            ItemStack drop = new ItemStack(state.getBlock().asItem());
            level.destroyBlock(pos, true);
            if (!event.getEntity().isCreative()) event.getEntity().getInventory().add(drop);
            spawnParticles(level, pos);
        }
    }

    private static void spawnParticles(Level level, BlockPos pos) {
        for (int i = 0; i < 10; i++) {
            double x = pos.getX() + Math.random();
            double y = pos.getY() + Math.random();
            double z = pos.getZ() + Math.random();
            level.addParticle(ParticleTypes.HAPPY_VILLAGER, x, y, z, 0, 0.05, 0);
        }
    }
}
