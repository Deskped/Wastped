package deskped.wastped.client.screens;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.GameRenderer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import deskped.wastped.procedures.IfRussianProcedure;
import deskped.wastped.procedures.IfMenuProcedure;
import deskped.wastped.procedures.IfEnglishProcedure;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class LogoSwingOverlay {
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        if (!IfMenuProcedure.execute()) return;
        boolean eng = IfEnglishProcedure.execute();
        boolean rus = IfRussianProcedure.execute();
        if (!eng && !rus) return;
        ResourceLocation tex = eng ? new ResourceLocation("wastped:textures/screens/wasteped.png")
                : new ResourceLocation("wastped:textures/screens/wasteped_ru.png");
        int w = event.getScreen().width;
        int h = event.getScreen().height;
        float imgW = 217f;
        float imgH = 110f;
        float x = w - 222f;
        float y = h / 2f - 109f;
        long ms = System.currentTimeMillis();
        double period = 4000.0;
        double angle = Math.sin(ms * (2.0 * Math.PI / period)) * 6.0;
        PoseStack pose = event.getGuiGraphics().pose();
        pose.pushPose();
        float cx = x + imgW / 2f;
        float cy = y + imgH / 2f;
        pose.translate(cx, cy, 0);
        pose.mulPose(Axis.ZP.rotationDegrees((float) angle));
        pose.translate(-cx, -cy, 0);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        event.getGuiGraphics().blit(tex, (int) x, (int) y, 0, 0, (int) imgW, (int) imgH, (int) imgW, (int) imgH);
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        pose.popPose();
    }
}
