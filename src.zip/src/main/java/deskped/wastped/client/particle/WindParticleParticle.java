package deskped.wastped.client.particle;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.multiplayer.ClientLevel;

@OnlyIn(Dist.CLIENT)
public class WindParticleParticle extends TextureSheetParticle {
	public static WindParticleParticleProvider provider(SpriteSet spriteSet) {
		return new WindParticleParticleProvider(spriteSet);
	}

	public static class WindParticleParticleProvider implements ParticleProvider<SimpleParticleType> {
		private final SpriteSet spriteSet;

		public WindParticleParticleProvider(SpriteSet spriteSet) {
			this.spriteSet = spriteSet;
		}

		public Particle createParticle(SimpleParticleType typeIn, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
			return new WindParticleParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed, this.spriteSet);
		}
	}

	private final SpriteSet spriteSet;

	protected WindParticleParticle(ClientLevel world, double x, double y, double z, double vx, double vy, double vz, SpriteSet spriteSet) {
		super(world, x, y, z);
		this.spriteSet = spriteSet;
		this.setSize(0.2f, 0.2f);
		this.quadSize *= 0.2f;
		this.lifetime = 7;
		this.gravity = 0f;
		this.hasPhysics = true;
		int colorType = (int)Math.round((vx - Math.floor(vx)) / 0.001);
		double baseVx = Math.floor(vx);
		this.xd = baseVx;
		this.yd = vy;
		this.zd = vz;
		applyColorByType(colorType);
		this.pickSprite(spriteSet);
	}

	@Override
	public ParticleRenderType getRenderType() {
		return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
	}

	@Override
	public void tick() {
		super.tick();
	}

	private void applyColorByType(int t) {
		switch (t) {
			case 1: setColor(0.94f, 0.83f, 0.62f); break;
			case 2: setColor(0.88f, 0.45f, 0.35f); break;
			case 3: setColor(0.33f, 0.65f, 0.30f); break;
			case 4: setColor(0.50f, 0.38f, 0.25f); break;
			case 5: setColor(0.6f, 0.6f, 0.6f); break;
			case 6: setColor(0.58f, 0.56f, 0.52f); break;
			case 7: setColor(0.7f, 0.7f, 0.66f); break;
			case 8: setColor(0.35f, 0.60f, 0.90f); break;
			case 9: setColor(0.9f, 0.35f, 0.1f); break;
			case 10: setColor(0.35f, 0.35f, 0.48f); break;
			case 11: setColor(0.45f, 0.12f, 0.12f); break;
			case 12: setColor(0.88f, 0.78f, 0.55f); break;
			case 13: setColor(0.95f, 0.95f, 0.98f); break;
			case 14: setColor(0.80f, 0.90f, 0.99f); break;
			case 15: setColor(0.66f, 0.50f, 0.35f); break;
			case 16: setColor(0.25f, 0.50f, 0.20f); break;
			case 17: setColor(0.95f, 0.65f, 0.10f); break;
			case 18: setColor(0.20f, 0.55f, 0.20f); break;
			case 19: setColor(0.75f, 0.75f, 0.80f); break;
			case 20: setColor(0.80f, 0.75f, 0.70f); break;
			case 21: setColor(0.45f, 0.45f, 0.48f); break;
			case 22: setColor(0.75f, 0.65f, 0.55f); break;
			case 23: setColor(0.85f, 0.92f, 0.95f); break;
			case 24: setColor(0.95f, 0.95f, 0.95f); break;
			case 25: setColor(0.97f, 0.91f, 0.00f); break;
			case 26: setColor(0.94f, 0.60f, 0.10f); break;
			case 27: setColor(0.88f, 0.36f, 0.85f); break;
			case 28: setColor(0.53f, 0.72f, 0.96f); break;
			case 29: setColor(0.00f, 0.74f, 0.74f); break;
			case 30: setColor(0.50f, 0.25f, 0.60f); break;
			case 31: setColor(0.20f, 0.30f, 0.80f); break;
			case 32: setColor(0.45f, 0.30f, 0.20f); break;
			case 33: setColor(0.15f, 0.55f, 0.15f); break;
			case 34: setColor(0.85f, 0.18f, 0.18f); break;
			case 35: setColor(0.08f, 0.08f, 0.08f); break;
			case 36: setColor(0.79f, 0.70f, 0.64f); break;
			case 37: setColor(0.64f, 0.22f, 0.17f); break;
			case 38: setColor(0.85f, 0.44f, 0.14f); break;
			case 39: setColor(0.92f, 0.78f, 0.35f); break;
			case 40: setColor(0.33f, 0.57f, 0.32f); break;
			case 41: setColor(0.22f, 0.36f, 0.55f); break;
			case 42: setColor(0.53f, 0.37f, 0.30f); break;
			case 43: setColor(0.45f, 0.40f, 0.50f); break;
			case 44: setColor(0.30f, 0.65f, 0.35f); break;
			case 45: setColor(0.45f, 0.95f, 0.45f); break;
			case 46: setColor(0.95f, 0.85f, 0.45f); break;
			default: setColor(0.90f, 0.90f, 0.90f); break;
		}
	}
}
