package deskped.wastped.client.model.animations;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.AnimationChannel;

public class gateAnimationOfflinetoonline {
	public static final AnimationDefinition offlinetoonline = AnimationDefinition.Builder.withLength(10.125F)
			.addAnimation("rightup", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(9.0417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.4583F, KeyframeAnimations.degreeVec(2.8342F, -2.5759F, -14.7822F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.7917F, KeyframeAnimations.degreeVec(-10.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("rightup", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(9.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.4583F, KeyframeAnimations.posVec(0.0F, 6.0F, -1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.7917F, KeyframeAnimations.posVec(0.0F, 4.0F, -2.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("right", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("left", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(9.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.3333F, KeyframeAnimations.posVec(0.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.6667F, KeyframeAnimations.posVec(0.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.9583F, KeyframeAnimations.posVec(0.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("leftup",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.0833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.3333F, KeyframeAnimations.degreeVec(17.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.625F, KeyframeAnimations.degreeVec(36.5037F, 5.9032F, -19.1431F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(31.25F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("leftup",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.3333F, KeyframeAnimations.posVec(0.0F, 7.0F, 1.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.625F, KeyframeAnimations.posVec(0.0F, 7.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("table",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("table",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.125F, KeyframeAnimations.posVec(0.0F, 8.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.2917F, KeyframeAnimations.posVec(0.0F, 17.5F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(9.5417F, KeyframeAnimations.posVec(0.0F, 17.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.875F, KeyframeAnimations.posVec(0.0F, 12.5F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("portallayerone",
					new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(9.2083F, KeyframeAnimations.scaleVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.25F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("portallayertwo",
					new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(9.2083F, KeyframeAnimations.scaleVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.25F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("portallayerthree",
					new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(9.2083F, KeyframeAnimations.scaleVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(9.25F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("crystal",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(42.0634F, -6.7372F, 7.407F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(1.2917F, KeyframeAnimations.degreeVec(42.0634F, -6.7372F, 7.407F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(1.875F, KeyframeAnimations.degreeVec(68.0304F, 13.0147F, -108.956F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.875F, KeyframeAnimations.degreeVec(245.5103F, 2.7811F, -211.9662F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(4.4583F, KeyframeAnimations.degreeVec(135.3347F, 26.6477F, 59.7017F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(5.8333F, KeyframeAnimations.degreeVec(267.4582F, 24.5307F, -148.9489F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(6.5417F, KeyframeAnimations.degreeVec(191.1793F, -27.5983F, -9.939F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(6.9167F, KeyframeAnimations.degreeVec(319.2873F, 21.7539F, 191.3054F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(7.25F, KeyframeAnimations.degreeVec(184.7247F, 30.5404F, 192.9291F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(7.625F, KeyframeAnimations.degreeVec(35.5194F, 13.3509F, 86.7821F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.0F, KeyframeAnimations.degreeVec(-80.619F, -20.9295F, -111.4371F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.7083F, KeyframeAnimations.degreeVec(5.0253F, -22.9987F, -15.1429F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(9.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("crystal", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(-14.2F, -5.0F, -22.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(0.7083F, KeyframeAnimations.posVec(-14.68F, -2.45F, -25.98F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(1.2917F, KeyframeAnimations.posVec(-14.2F, -5.0F, -22.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(1.875F, KeyframeAnimations.posVec(-7.19F, 31.01F, 36.61F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(2.875F, KeyframeAnimations.posVec(29.8F, 28.0F, -33.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(5.8333F, KeyframeAnimations.posVec(56.8F, -6.0F, 2.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.5417F, KeyframeAnimations.posVec(-14.62F, 38.81F, 55.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(7.625F, KeyframeAnimations.posVec(-0.72F, 49.02F, -74.66F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.5417F, KeyframeAnimations.posVec(11.7F, 10.93F, 11.6F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(9.1667F, KeyframeAnimations.posVec(2.0F, 2.0F, -1.9F), AnimationChannel.Interpolations.LINEAR), new Keyframe(10.0F, KeyframeAnimations.posVec(2.6F, 2.4F, -1.3F), AnimationChannel.Interpolations.LINEAR)))
			.build();
}