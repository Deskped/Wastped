/*
package deskped.wastped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.blaze3d.systems.RenderSystem;

import java.lang.reflect.Field;
import java.util.*;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "wastped")
@OnlyIn(Dist.CLIENT)
public class Menu {

    private static boolean useCustomMenu = true;
    private static boolean hiddenElements = false;

    private static final int TOTAL_FRAMES = 10;
    private static final int FPS = 15;
    private static long lastFrameTime = 0;
    private static int currentFrame = 0;

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        if (!(screen instanceof TitleScreen)) return;

        Minecraft mc = Minecraft.getInstance();
        hiddenElements = false;
        currentFrame = 0;
        lastFrameTime = System.currentTimeMillis();

        if (useCustomMenu) {
            List<Object> snapshot = new ArrayList<>(event.getListenersList());
            for (Object o : snapshot) {
                if (o instanceof Button btn) event.removeListener(btn);
            }

            int buttonWidth = 100;
            int buttonHeight = 20;
            int spacing = 24;
            int marginRight = 10;

            int x = screen.width - marginRight - buttonWidth;
            if (x < 10) x = 10;

            int totalButtons = 4;
            int totalHeight = totalButtons * spacing;
            int startY = screen.height - totalHeight - 10;

            event.addListener(Button.builder(Component.translatable("menu.singleplayer"), b ->
                    mc.setScreen(new SelectWorldScreen(screen))
            ).bounds(x, startY, buttonWidth, buttonHeight).build());
            startY += spacing;

            event.addListener(Button.builder(Component.translatable("menu.multiplayer"), b ->
                    mc.setScreen(new JoinMultiplayerScreen(screen))
            ).bounds(x, startY, buttonWidth, buttonHeight).build());
            startY += spacing;

            event.addListener(Button.builder(Component.translatable("menu.options"), b ->
                    mc.setScreen(new OptionsScreen(screen, mc.options))
            ).bounds(x, startY, buttonWidth, buttonHeight).build());
            startY += spacing;

            event.addListener(Button.builder(Component.translatable("menu.quit"), b ->
                    mc.stop()
            ).bounds(x, startY, buttonWidth, buttonHeight).build());

            ButtonAnimation.initForScreen(screen);
        }

        event.addListener(Button.builder(Component.literal("⟳"), b -> {
            useCustomMenu = !useCustomMenu;
            mc.setScreen(new TitleScreen());
        }).bounds(5, 5, 20, 20).build());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onScreenRenderPre(ScreenEvent.Render.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        if (!useCustomMenu) return;

        event.setCanceled(true);

        Screen screen = event.getScreen();
        GuiGraphics guiGraphics = event.getGuiGraphics();

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFrameTime >= 5000 / FPS) {
            currentFrame = (currentFrame + 1) % TOTAL_FRAMES;
            lastFrameTime = currentTime;
        }

        String frameNumber = String.format("%04d", currentFrame + 1);
        String frameName = "frame_" + frameNumber + "_" + currentFrame + "_00s.png";
        ResourceLocation frameTexture = ResourceLocation.fromNamespaceAndPath("wastped", "textures/gui/bg/" + frameName);

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        guiGraphics.blit(frameTexture, 0, 0, 0, 0, screen.width, screen.height, screen.width, screen.height);

        if (!hiddenElements) {
            hideLogoAndForgeText(screen);
            hiddenElements = true;
        }

        ButtonAnimation.update(screen, event.getMouseX(), event.getMouseY());

        for (Renderable renderable : screen.renderables) {
            renderable.render(guiGraphics, event.getMouseX(), event.getMouseY(), event.getPartialTick());
        }
    }

    @SubscribeEvent
    public static void onScreenRenderPost(ScreenEvent.Render.Post event) {
        Screen screen = event.getScreen();
        if (!(screen instanceof TitleScreen)) return;

        if (useCustomMenu) {
            Particles.updateMovement(event.getMouseX(), event.getMouseY());
            Particles.updateFade();
            Particles.spawnParticles(screen.width, screen.height);
            Particles.updateParticles();
            Particles.drawParticles(event.getGuiGraphics());
        }
    }

    private static void hideLogoAndForgeText(Screen screen) {
        try {
            Field renderablesField = Screen.class.getDeclaredField("renderables");
            renderablesField.setAccessible(true);
            List<Renderable> renderables = (List<Renderable>) renderablesField.get(screen);
            renderables.removeIf(r -> !(r instanceof AbstractWidget));
        } catch (Exception ignored) {}
    }

    static class ButtonAnimation {

        private static final Map<AbstractWidget, AnimData> anim = new HashMap<>();

        static class AnimData {
            final double baseX, baseY, ampX, ampY, speed, phase, hoverPush;
            AnimData(double bx, double by, double ax, double ay, double s, double p, double hp) {
                baseX = bx;
                baseY = by;
                ampX = ax;
                ampY = ay;
                speed = s;
                phase = p;
                hoverPush = hp;
            }
        }

        static void initForScreen(Screen screen) {
            anim.clear();
            for (Object o : screen.children()) {
                if (o instanceof AbstractWidget w) {
                    if (w.getX() == 5 && w.getY() == 5) continue;

                    anim.put(w, new AnimData(
                            w.getX(),
                            w.getY(),
                            0.5 + Math.random() * 1.5,
                            0.5 + Math.random() * 1.5,
                            0.0015 + Math.random() * 0.003,
                            Math.random() * Math.PI * 2,
                            2 + Math.random() * 3
                    ));
                }
            }
        }

        static void update(Screen screen, int mouseX, int mouseY) {
            long t = System.currentTimeMillis();

            for (var e : anim.entrySet()) {
                AbstractWidget w = e.getKey();
                AnimData d = e.getValue();

                double sx = Math.sin(t * d.speed + d.phase) * d.ampX;
                double sy = Math.cos(t * d.speed * 1.1 + d.phase * 0.5) * d.ampY;

                double cx = d.baseX + sx;
                double cy = d.baseY + sy;

                double centerX = cx + w.getWidth() / 2.0;
                double centerY = cy + w.getHeight() / 2.0;

                double dx = mouseX - centerX;
                double dy = mouseY - centerY;
                double dist = Math.sqrt(dx * dx + dy * dy);

                double influence = Math.max(32, Math.max(w.getWidth(), w.getHeight()) * 1.5);

                double hx = 0, hy = 0;
                if (dist < influence && dist > 0.001) {
                    double inv = 1 - dist / influence;
                    double push = d.hoverPush * inv;
                    hx = -dx / dist * push;
                    hy = -dy / dist * push;
                }

                double targetX = cx + hx;
                double targetY = cy + hy;

                double lerp = 0.35;

                w.setPosition(
                        (int) Math.round(w.getX() * (1 - lerp) + targetX * lerp),
                        (int) Math.round(w.getY() * (1 - lerp) + targetY * lerp)
                );
            }
        }
    }

    static class Particles {

        private static final List<Particle> particles = new ArrayList<>();
        private static final Random random = new Random();
        private static float offsetX, offsetY, fade;

        static void updateMovement(int mouseX, int mouseY) {
            float cx = Minecraft.getInstance().getWindow().getGuiScaledWidth() * 0.5f;
            float cy = Minecraft.getInstance().getWindow().getGuiScaledHeight() * 0.5f;
            offsetX += ((mouseX - cx) * 0.015f - offsetX) * 0.06f;
            offsetY += ((mouseY - cy) * 0.015f - offsetY) * 0.06f;
        }

        static void updateFade() {
            fade += (1f - fade) * 0.02f;
            if (fade > 1f) fade = 1f;
        }

        static void spawnParticles(int width, int height) {
            if (random.nextFloat() < 2f) {
                float x = -random.nextFloat() * 120f;
                float y = random.nextFloat() * height;
                float vx = 6f + random.nextFloat() * 10f;
                float vy = (random.nextFloat() - 0.5f) * 0.6f;
                float size = 3f + random.nextFloat() * 3f;

                int alpha = 120 + random.nextInt(136);

                int baseR = 219;
                int baseG = 207;
                int baseB = 163;

                int r = baseR + random.nextInt(20) - 10;
                int g = baseG + random.nextInt(20) - 10;
                int b = baseB + random.nextInt(20) - 10;

                int color = (alpha << 24)
                        | (Math.max(0, Math.min(255, r)) << 16)
                        | (Math.max(0, Math.min(255, g)) << 8)
                        | Math.max(0, Math.min(255, b));


                particles.add(new Particle(x, y, vx, vy, size, 1f, color));
            }
        }

        static void updateParticles() {
            int width = Minecraft.getInstance().getWindow().getGuiScaledWidth();
            particles.removeIf(p -> p.life <= 0 || p.x > width + 100 || Float.isNaN(p.x));
            for (Particle p : particles) p.update();
        }

        static void drawParticles(GuiGraphics g) {
            g.pose().pushPose();
            g.pose().translate(offsetX, offsetY, 0);

            for (Particle p : particles) {
                int baseA = (p.color >>> 24);
                int a = (int) (baseA * p.life * fade);
                int col = (a << 24) | (p.color & 0xFFFFFF);

                int x0 = (int) (p.x - p.size * 0.5f);
                int y0 = (int) (p.y - p.size * 0.5f);
                int x1 = (int) (p.x + p.size * 0.5f);
                int y1 = (int) (p.y + p.size * 0.5f);

                g.fill(x0, y0, x1, y1, col);
            }

            g.pose().popPose();
        }

        static class Particle {
            float x, y, vx, vy, size, life;
            int color;

            Particle(float x, float y, float vx, float vy, float size, float life, int color) {
                this.x = x;
                this.y = y;
                this.vx = vx;
                this.vy = vy;
                this.size = size;
                this.life = life;
                this.color = color;
            }

            void update() {
                x += vx;
                vy += 0.03f * Math.sin(x * 0.06f);
                y += vy;
                vx *= 0.998f;
                vy *= 0.997f;
                life -= 0.004f;
                size *= 0.999f;
            }
        }
    }
}


*/