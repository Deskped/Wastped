package deskped.wastped.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TumaniteCrystalItem extends Item {
	public TumaniteCrystalItem() {
		super(new Item.Properties().rarity(Rarity.EPIC));
	}
}