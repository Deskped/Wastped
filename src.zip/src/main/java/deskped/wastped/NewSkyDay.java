package deskped.wastped;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.math.Axis;

@Mod.EventBusSubscriber(modid = "wastped", value = Dist.CLIENT)
public class NewSkyDay {

    private static final ResourceLocation CUSTOM_SUN =
            new ResourceLocation("wastped", "textures/environment/your_start.png");

    private static final ResourceLocation ALLOWED_DIM_1 =
            new ResourceLocation("wastped", "waste");

    private static final ResourceLocation ALLOWED_DIM_2 =
            new ResourceLocation("wastped", "waste");

    @SubscribeEvent
    public static void onRenderSky(RenderLevelStageEvent event) {

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;

        if (level == null) return;

        ResourceLocation dim = level.dimension().location();

        if (dim == null) return;
        if (!dim.equals(ALLOWED_DIM_1) && !dim.equals(ALLOWED_DIM_2)) return;

        long time = level.getDayTime() % 24000;

        if (time >= 11800 && time <= 23200) return;

        float alpha;

        if (time < 2000) {
            float t = time / 2000f;
            alpha = 0.2f * t;
        } else if (time > 10000 && time < 11800) {
            float t = (11800 - time) / 1800f;
            alpha = 0.2f + 0.1f * t;
        } else {
            alpha = 0.3f;
        }

        alpha = Math.min(Math.max(alpha, 0f), 1f);

        PoseStack poseStack = event.getPoseStack();

        poseStack.pushPose();

        float rotation = (level.getGameTime() % 360000L) / 100f;
        poseStack.mulPose(Axis.YP.rotationDegrees(rotation));

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, CUSTOM_SUN);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        RenderSystem.setShaderColor(1F, 1F, 1F, alpha);

        float sunSize = 160F;

        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.getBuilder();

        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);

        buffer.vertex(poseStack.last().pose(), -sunSize, 100F, -sunSize).uv(0F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  sunSize, 100F, -sunSize).uv(1F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  sunSize, 100F,  sunSize).uv(1F, 1F).endVertex();
        buffer.vertex(poseStack.last().pose(), -sunSize, 100F,  sunSize).uv(0F, 1F).endVertex();

        tesselator.end();

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();

        poseStack.popPose();
    }
}
