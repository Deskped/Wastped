package deskped.wastped;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DynamicLight {
private static final Map<UUID, BlockPos> PREV_POS = new ConcurrentHashMap<>();
private static final Map<UUID, Integer> PREV_LEVEL = new ConcurrentHashMap<>();

@SubscribeEvent
public static void onServerTick(TickEvent.ServerTickEvent event) {
	if (event.phase != TickEvent.Phase.END) return;
	MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
	if (server == null) return;

	for (ServerPlayer player : server.getPlayerList().getPlayers()) {
		if (player.isSpectator()) continue;
		Level world = player.level();
		if (world.isClientSide) continue;

		UUID id = player.getUUID();
		int level = calcLight(player);
		BlockPos pos = player.blockPosition();

		BlockPos prev = PREV_POS.get(id);
		Integer prevLevel = PREV_LEVEL.get(id);

		if (level > 0) {
			if (world.getBlockState(pos).isAir() || world.getBlockState(pos).is(Blocks.LIGHT)) {
				world.setBlock(pos, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, level), 3);
				PREV_POS.put(id, pos);
				PREV_LEVEL.put(id, level);
			}
		}

		if (prev != null && (!prev.equals(pos) || level == 0)) {
			BlockState bs = world.getBlockState(prev);
			if (bs.is(Blocks.LIGHT) && bs.getValue(LightBlock.LEVEL).equals(prevLevel)) {
				world.setBlock(prev, Blocks.AIR.defaultBlockState(), 3);
			}
			if (level == 0) {
				PREV_POS.remove(id);
				PREV_LEVEL.remove(id);
			}
		}
	}
}

private static int calcLight(ServerPlayer player) {
	if (player.isOnFire()) return 15;
	int main = getLightFromItem(player.getMainHandItem());
	int off = getLightFromItem(player.getOffhandItem());
	return Math.max(main, off);
}

private static int getLightFromItem(ItemStack stack) {
	if (stack == null || stack.isEmpty()) return 0;

	if (stack.getItem() instanceof BlockItem bi) {
		Block block = bi.getBlock();
		int auto = block.defaultBlockState().getLightEmission();
		if (auto > 0) return auto;

		if (block == Blocks.CAMPFIRE) return 15;
		if (block == Blocks.SOUL_CAMPFIRE) return 10;
		if (block == Blocks.CANDLE || block == Blocks.WHITE_CANDLE || block == Blocks.ORANGE_CANDLE
				|| block == Blocks.MAGENTA_CANDLE || block == Blocks.LIGHT_BLUE_CANDLE
				|| block == Blocks.YELLOW_CANDLE || block == Blocks.LIME_CANDLE
				|| block == Blocks.PINK_CANDLE || block == Blocks.GRAY_CANDLE
				|| block == Blocks.LIGHT_GRAY_CANDLE || block == Blocks.CYAN_CANDLE
				|| block == Blocks.PURPLE_CANDLE || block == Blocks.BLUE_CANDLE
				|| block == Blocks.BROWN_CANDLE || block == Blocks.GREEN_CANDLE
				|| block == Blocks.RED_CANDLE || block == Blocks.BLACK_CANDLE) return 3;

		if (block == Blocks.RESPAWN_ANCHOR) return 15;
		if (block == Blocks.SEA_PICKLE) return 15;
		if (block == Blocks.REDSTONE_LAMP) return 15;
		if (block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE || block == Blocks.SMOKER) return 13;
		if (block == Blocks.SCULK_CATALYST || block == Blocks.SCULK_SENSOR) return 6;
	}

	if (stack.is(Items.TORCH)) return 14;
	if (stack.is(Items.SOUL_TORCH)) return 10;
	if (stack.is(Items.LANTERN)) return 15;
	if (stack.is(Items.SOUL_LANTERN)) return 10;
	if (stack.is(Items.GLOWSTONE)) return 15;
	if (stack.is(Items.SEA_LANTERN)) return 15;
	if (stack.is(Items.SHROOMLIGHT)) return 15;
	if (stack.is(Items.OCHRE_FROGLIGHT) || stack.is(Items.PEARLESCENT_FROGLIGHT) || stack.is(Items.VERDANT_FROGLIGHT)) return 15;
	if (stack.is(Items.END_ROD)) return 14;
	if (stack.is(Items.JACK_O_LANTERN)) return 15;
	if (stack.is(Items.GLOW_BERRIES)) return 12;
	if (stack.is(Items.LAVA_BUCKET)) return 15;
	if (stack.is(Items.FIRE_CHARGE) || stack.is(Items.FLINT_AND_STEEL)) return 15;

	ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
	if (key != null && "wastped:tumanite_crystal".equals(key.toString())) return 6;

	return 0;
}

}
