package deskped.wastped;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.math.Axis;
import org.checkerframework.checker.units.qual.Speed;

@Mod.EventBusSubscriber(modid = "wastped", value = Dist.CLIENT)
public class NewSkyAdd {

    private static final ResourceLocation CUSTOM_MOON =
            new ResourceLocation("wastped", "textures/environment/your_nova.png");

    private static final ResourceLocation ALLOWED_DIM_1 =
            new ResourceLocation("wastped", "waste");

    private static final ResourceLocation ALLOWED_DIM_2 =
            new ResourceLocation("wastped", "waste");

    @SubscribeEvent
    public static void onRenderSky(RenderLevelStageEvent event) {

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;

        if (level == null) return;

        ResourceLocation dim = level.dimension().location();

        if (dim == null) return;
        if (!dim.equals(ALLOWED_DIM_1) && !dim.equals(ALLOWED_DIM_2)) return;

        long time = level.getDayTime() % 24000;

        if (time < 11800 || time > 23200) return;

        float alpha;

        if (time <= 13800) {
            float t = (time - 11800) / 2000f;
            t = Math.min(Math.max(t, 0f), 1f);
            alpha = 0.5f - 0.5f * (float) Math.cos(Math.PI * t);
        } else if (time >= 21200) {
            float t = (23200 - time) / 2000f;
            t = Math.min(Math.max(t, 0f), 1f);
            alpha = 0.5f - 0.5f * (float) Math.cos(Math.PI * t);
        } else {
            alpha = 1.0f;
        }

        alpha = Math.min(Math.max(alpha, 0f), 1f);

        PoseStack poseStack = event.getPoseStack();

        poseStack.pushPose();

        float rotation = (level.getGameTime() % 36000L) / -100f;
        poseStack.mulPose(Axis.YP.rotationDegrees(rotation));

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, CUSTOM_MOON);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        RenderSystem.setShaderColor(1F, 1F, 1F, alpha);

        float speed = 10000F;
        float moonSize = 160F;
        float height = 60F;

        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.getBuilder();

        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);

        buffer.vertex(poseStack.last().pose(), -moonSize, height, -moonSize).uv(0F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  moonSize, height, -moonSize).uv(1F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  moonSize, height,  moonSize).uv(1F, 1F).endVertex();
        buffer.vertex(poseStack.last().pose(), -moonSize, height,  moonSize).uv(0F, 1F).endVertex();

        tesselator.end();

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();

        poseStack.popPose();
    }
}
