package net.deskped.wastped;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class HARDCORE {
    public HARDCORE() {}

    @SubscribeEvent
    public static void setup(FMLCommonSetupEvent event) {}

    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {

        private static final double FIXED_HEALTH = 20.0D;
        private static final String BLINK_TAG = "myped_lowHealthBlink";

        @SubscribeEvent
        public static void onEntityAttributeModification(EntityAttributeModificationEvent event) {
            event.add(EntityType.PLAYER, Attributes.MAX_HEALTH, FIXED_HEALTH);
            event.add(EntityType.PLAYER, Attributes.ARMOR, 0.0D);
            event.add(EntityType.PLAYER, Attributes.ARMOR_TOUGHNESS, 0.0D);
        }

        @SubscribeEvent
        public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
            enforceFixedHealth((Player) event.getEntity());
        }

        @SubscribeEvent
        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            enforceFixedHealth((Player) event.getEntity());
        }

        @SubscribeEvent
        public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
            if (!event.player.level().isClientSide) {
                Player p = event.player;
                enforceFixedHealth(p);
                if (!p.isCreative() && !p.isSpectator()) {
                    if (p.getAbilities().mayfly) {
                        p.getAbilities().mayfly = false;
                        p.getAbilities().flying = false;
                        p.onUpdateAbilities();
                    }
                    if (p.isFallFlying()) {
                        p.stopFallFlying();
                    }
                }
                if (!p.isCreative() && !p.isSpectator()) {
                    if (p.getHealth() < 3.0F) {
                        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0, false, false, true));
                        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false, true));
                    }
                    if (p.getHealth() <= 1.0F) {
                        CompoundTag data = p.getPersistentData();
                        int ticks = data.getInt(BLINK_TAG) + 1;
                        data.putInt(BLINK_TAG, ticks);
                    } else {
                        p.getPersistentData().putInt(BLINK_TAG, 0);
                    }
                }
            }
        }

        private static void enforceFixedHealth(Player p) {
            if (p.getAttribute(Attributes.MAX_HEALTH) != null &&
                p.getAttribute(Attributes.MAX_HEALTH).getBaseValue() != FIXED_HEALTH) {
                p.getAttribute(Attributes.MAX_HEALTH).setBaseValue(FIXED_HEALTH);
            }
            if (p.getHealth() > (float) FIXED_HEALTH) {
                p.setHealth((float) FIXED_HEALTH);
            }
        }

        @SubscribeEvent
        public static void onLivingHurt(LivingHurtEvent event) {
            if (!(event.getEntity() instanceof Player)) return;
            Player player = (Player) event.getEntity();
            if (player.isCreative() || player.isSpectator()) return;

            DamageSource src = event.getSource();
            Entity srcEntity = src.getEntity();
            Entity direct = src.getDirectEntity();

            boolean fromPlayer = srcEntity instanceof Player;

            boolean projectile = false;
            if (direct != null) {
                String cls = direct.getClass().getName().toLowerCase();
                if (cls.contains("arrow") || cls.contains("trident") || cls.contains("projectile") || cls.contains("fireball") || cls.contains("snowball") || cls.contains("egg")) {
                    projectile = true;
                }
            }

            String id = src.getMsgId() == null ? "" : src.getMsgId().toLowerCase();
            boolean magicOrEffect = id.contains("magic") || id.contains("indirect") || id.contains("wither") || id.contains("poison") || id.contains("thorns");
            boolean fromCommand = id.contains("command");
            boolean outOfWorld = id.contains("out_of_world") || id.contains("outofworld") || id.contains("void") || id.contains("kill");

            boolean isException = fromCommand || magicOrEffect || fromPlayer || projectile || outOfWorld;

            if (!isException) {
                float currentHealth = player.getHealth();
                float requested = event.getAmount();
                float maxAllowedDamage = currentHealth - 1.0F;
                if (maxAllowedDamage <= 0.0F) {
                    event.setCanceled(true);
                    return;
                }
                if (requested > maxAllowedDamage) {
                    event.setAmount(maxAllowedDamage);
                }
            }
        }
    }
}
