package deskped.wastped.network;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WastpedModVariables {
	public static boolean custommenu = true;

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
	}
}