/*
package deskped.wastped;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import org.joml.Vector3f;

import java.util.Random;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Wind {

    private static final ResourceLocation ALLOWED_DIM_1 = new ResourceLocation("wasteped", "waste");
    private static final ResourceLocation ALLOWED_DIM_2 = new ResourceLocation("wastped", "waste");

    @SubscribeEvent
    public static void init(FMLCommonSetupEvent event) {}

    @Mod.EventBusSubscriber
    private static class WindForgeBusEvents {

        private static final Random random = new Random();
        private static int tickCounter = 0;
        private static SimpleParticleType windParticle = null;

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;

            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null || mc.isPaused()) return;

            ResourceLocation dimLoc = mc.level.dimension().location();
            if (dimLoc == null) return;
            if (!dimLoc.equals(ALLOWED_DIM_1) && !dimLoc.equals(ALLOWED_DIM_2)) return;

            if (windParticle == null) {
                ParticleType<?> t = BuiltInRegistries.PARTICLE_TYPE.get(new ResourceLocation("westped", "wind_particle"));
                if (t instanceof SimpleParticleType) windParticle = (SimpleParticleType) t;
            }

            Vec3 pos = mc.player.position();
            BlockPos underPos = BlockPos.containing(pos.x, pos.y - 1.0, pos.z);
            Block blockUnder = mc.level.getBlockState(underPos).getBlock();
            int colorType = mapBlockToColorType(blockUnder);
            float[] rgb = colorTypeToRgb(colorType);

            tickCounter++;

            int particlesToSpawn = 33 + random.nextInt(66);

            for (int i = 0; i < particlesToSpawn; i++) {
                double angle = random.nextDouble() * Math.PI * 4;
                double distance = 1 + random.nextDouble() * 32;

                double spawnX = pos.x - distance + random.nextDouble() * 4;
                double spawnY = pos.y + random.nextDouble() * 12 - 2;
                double spawnZ = pos.z + Math.sin(angle) * distance;

                int baseVxInt =  (int)Math.floor(0.8 + random.nextDouble() * 1.2);
                double vxWithColor = baseVxInt + (colorType * 0.001);

                double velocityY = (random.nextDouble() - 0.5) * 0.08;
                double velocityZ = (random.nextDouble() - 0.5) * 0.08;

                double wave = Math.sin(tickCounter * 0.05 + spawnY * 0.1) * 0.02;
                velocityY += wave;

                if (windParticle != null) {
                    mc.level.addParticle(windParticle, true, spawnX, spawnY, spawnZ, vxWithColor, velocityY, velocityZ);
                } else {
                    ParticleOptions fallback = new DustParticleOptions(new Vector3f(rgb[0], rgb[1], rgb[2]), 0.6f);
                    mc.level.addParticle(fallback, spawnX, spawnY, spawnZ, (double)baseVxInt, velocityY, velocityZ);
                }
            }
        }

        private static int mapBlockToColorType(Block b) {
            if (b == Blocks.BEDROCK) return 1;
            if (b == Blocks.RED_SAND || b == Blocks.RED_SANDSTONE) return 2;
            if (b == Blocks.GRASS_BLOCK || b == Blocks.TALL_GRASS || b == Blocks.MOSS_BLOCK) return 3;
            if (b == Blocks.DIRT || b == Blocks.COARSE_DIRT || b == Blocks.FARMLAND) return 4;
            if (b == Blocks.STONE || b == Blocks.COBBLESTONE || b == Blocks.DEEPSLATE) return 5;
            if (b == Blocks.ANDESITE || b == Blocks.DIORITE || b == Blocks.GRANITE) return 6;
            if (b == Blocks.GRAVEL) return 7;
            if (b == Blocks.WATER || b == Blocks.BUBBLE_COLUMN) return 8;
            if (b == Blocks.LAVA) return 9;
            if (b == Blocks.SOUL_SAND || b == Blocks.SOUL_SOIL) return 10;
            if (b == Blocks.NETHERRACK || b == Blocks.NETHER_BRICKS || b == Blocks.BASALT) return 11;
            if (b == Blocks.END_STONE || b == Blocks.PURPUR_BLOCK) return 12;
            if (b == Blocks.SNOW || b == Blocks.SNOW_BLOCK) return 13;
            if (b == Blocks.ICE || b == Blocks.PACKED_ICE || b == Blocks.BLUE_ICE) return 14;
            if (b == Blocks.OAK_PLANKS || b == Blocks.SPRUCE_PLANKS || b == Blocks.BIRCH_PLANKS
                    || b == Blocks.JUNGLE_PLANKS || b == Blocks.ACACIA_PLANKS || b == Blocks.DARK_OAK_PLANKS) return 15;
            if (b == Blocks.OAK_LEAVES || b == Blocks.SPRUCE_LEAVES || b == Blocks.BIRCH_LEAVES
                    || b == Blocks.JUNGLE_LEAVES || b == Blocks.ACACIA_LEAVES || b == Blocks.DARK_OAK_LEAVES) return 16;
            if (b == Blocks.PUMPKIN || b == Blocks.CARVED_PUMPKIN) return 17;
            if (b == Blocks.MELON) return 18;
            if (b == Blocks.CLAY) return 19;
            if (b == Blocks.COBBLED_DEEPSLATE || b == Blocks.POLISHED_DEEPSLATE) return 20;
            if (b == Blocks.IRON_BLOCK || b == Blocks.GOLD_BLOCK || b == Blocks.COPPER_BLOCK
                    || b == Blocks.LAPIS_BLOCK || b == Blocks.REDSTONE_BLOCK) return 21;
            if (b == Blocks.GLASS || b == Blocks.GLASS_PANE) return 22;
            if (b == Blocks.WHITE_WOOL) return 23;
            if (b == Blocks.YELLOW_WOOL) return 24;
            if (b == Blocks.ORANGE_WOOL) return 25;
            if (b == Blocks.MAGENTA_WOOL) return 26;
            if (b == Blocks.LIGHT_BLUE_WOOL) return 27;
            if (b == Blocks.CYAN_WOOL) return 28;
            if (b == Blocks.PURPLE_WOOL) return 29;
            if (b == Blocks.BLUE_WOOL) return 30;
            if (b == Blocks.BROWN_WOOL) return 31;
            if (b == Blocks.GREEN_WOOL) return 32;
            if (b == Blocks.RED_WOOL) return 33;
            if (b == Blocks.BLACK_WOOL) return 34;
            if (b == Blocks.TERRACOTTA || b == Blocks.WHITE_TERRACOTTA) return 35;
            if (b == Blocks.RED_TERRACOTTA) return 36;
            if (b == Blocks.ORANGE_TERRACOTTA) return 37;
            if (b == Blocks.YELLOW_TERRACOTTA) return 38;
            if (b == Blocks.GREEN_TERRACOTTA) return 39;
            if (b == Blocks.BLUE_TERRACOTTA) return 40;
            if (b == Blocks.BROWN_TERRACOTTA) return 41;
            if (b == Blocks.MYCELIUM) return 42;
            if (b == Blocks.SLIME_BLOCK) return 43;
            if (b == Blocks.HONEY_BLOCK) return 44;
            return 0;
        }

        private static float[] colorTypeToRgb(int t) {
            switch (t) {
                case 1: return new float[]{0.94f, 0.83f, 0.62f};
                case 2: return new float[]{0.88f, 0.45f, 0.35f};
                case 3: return new float[]{0.33f, 0.65f, 0.30f};
                case 4: return new float[]{0.50f, 0.38f, 0.25f};
                case 5: return new float[]{0.6f, 0.6f, 0.6f};
                case 6: return new float[]{0.58f, 0.56f, 0.52f};
                case 7: return new float[]{0.7f, 0.7f, 0.66f};
                case 8: return new float[]{0.35f, 0.60f, 0.90f};
                case 9: return new float[]{0.9f, 0.35f, 0.1f};
                case 10: return new float[]{0.35f, 0.35f, 0.48f};
                case 11: return new float[]{0.45f, 0.12f, 0.12f};
                case 12: return new float[]{0.88f, 0.78f, 0.55f};
                case 13: return new float[]{0.95f, 0.95f, 0.98f};
                case 14: return new float[]{0.80f, 0.90f, 0.99f};
                case 15: return new float[]{0.66f, 0.50f, 0.35f};
                case 16: return new float[]{0.25f, 0.50f, 0.20f};
                case 17: return new float[]{0.95f, 0.65f, 0.10f};
                case 18: return new float[]{0.20f, 0.55f, 0.20f};
                case 19: return new float[]{0.75f, 0.75f, 0.80f};
                case 20: return new float[]{0.45f, 0.45f, 0.48f};
                case 21: return new float[]{0.75f, 0.65f, 0.55f};
                case 22: return new float[]{0.85f, 0.92f, 0.95f};
                case 23: return new float[]{0.95f, 0.95f, 0.95f};
                case 24: return new float[]{0.97f, 0.91f, 0.00f};
                case 25: return new float[]{0.94f, 0.60f, 0.10f};
                case 26: return new float[]{0.88f, 0.36f, 0.85f};
                case 27: return new float[]{0.53f, 0.72f, 0.96f};
                case 28: return new float[]{0.00f, 0.74f, 0.74f};
                case 29: return new float[]{0.50f, 0.25f, 0.60f};
                case 30: return new float[]{0.20f, 0.30f, 0.80f};
                case 31: return new float[]{0.45f, 0.30f, 0.20f};
                case 32: return new float[]{0.15f, 0.55f, 0.15f};
                case 33: return new float[]{0.85f, 0.18f, 0.18f};
                case 34: return new float[]{0.08f, 0.08f, 0.08f};
                case 35: return new float[]{0.79f, 0.70f, 0.64f};
                case 36: return new float[]{0.64f, 0.22f, 0.17f};
                case 37: return new float[]{0.85f, 0.44f, 0.14f};
                case 38: return new float[]{0.92f, 0.78f, 0.35f};
                case 39: return new float[]{0.33f, 0.57f, 0.32f};
                case 40: return new float[]{0.22f, 0.36f, 0.55f};
                case 41: return new float[]{0.53f, 0.37f, 0.30f};
                case 42: return new float[]{0.45f, 0.40f, 0.50f};
                case 43: return new float[]{0.30f, 0.65f, 0.35f};
                case 44: return new float[]{0.45f, 0.95f, 0.45f};
                default: return new float[]{0.90f, 0.90f, 0.90f};
            }
        }
    }
}

*/