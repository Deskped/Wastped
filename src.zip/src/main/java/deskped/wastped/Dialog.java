package deskped.wastped;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.Commands;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Dialog {
    public static final String MODID = "wastped";

    @SuppressWarnings("removal")
    private static final ResourceLocation PROTOCOL = new ResourceLocation(MODID + ":dialog_channel");

    private static SimpleChannel CHANNEL;
    private static final int PROTOCOL_VERSION = 1;
    private static final Map<UUID, String> playerNames = new ConcurrentHashMap<>();

    public Dialog() {}

    @SubscribeEvent
    public static void init(FMLCommonSetupEvent event) {
        CHANNEL = NetworkRegistry.newSimpleChannel(
                PROTOCOL,
                () -> Integer.toString(PROTOCOL_VERSION),
                s -> true,
                s -> true
        );
        int id = 0;
        CHANNEL.registerMessage(id++, ClientToServerDialogMessage.class, ClientToServerDialogMessage::encode, ClientToServerDialogMessage::decode, ClientToServerDialogMessage::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, ServerToClientDialogMessage.class, ServerToClientDialogMessage::encode, ServerToClientDialogMessage::decode, ServerToClientDialogMessage::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {
        @SubscribeEvent
        public static void onRegisterCommands(RegisterCommandsEvent event) {
            event.getDispatcher().register(
                Commands.literal("wastped").then(
                    Commands.literal("setname")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String cur = playerNames.getOrDefault(player.getUUID(), "NPC");
                            ctx.getSource().sendSuccess(() -> Component.literal("Current character name: " + cur + ". Usage: /westped setname <name>"), false);
                            return 1;
                        })
                        .then(Commands.argument("name", StringArgumentType.greedyString()).executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String name = StringArgumentType.getString(ctx, "name");
                            playerNames.put(player.getUUID(), name);
                            ctx.getSource().sendSuccess(() -> Component.literal("Name set to: " + name), false);
                            return 1;
                        }))
                )
            );
        }
    }

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ClientEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent evt) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientDialogManager::noop);
        }

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onClientChat(ClientChatEvent event) {
            ClientDialogManager.onClientChat(event);
        }

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onRenderGui(RenderGuiOverlayEvent.Post event) {
            ClientDialogManager.onRenderGui(event);
        }

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            ClientDialogManager.onClientTick(event);
        }

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            ClientDialogManager.onPlayerLogout(event);
        }

        @OnlyIn(Dist.CLIENT)
        @SubscribeEvent
        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            ClientDialogManager.onPlayerRespawn(event);
        }
    }

    public static class ClientToServerDialogMessage {
        public final String message;
        public final boolean named;

        public ClientToServerDialogMessage(String message, boolean named) {
            this.message = message;
            this.named = named;
        }

        public static void encode(ClientToServerDialogMessage pkt, FriendlyByteBuf buf) {
            byte[] bytes = pkt.message.getBytes(StandardCharsets.UTF_8);
            buf.writeInt(bytes.length);
            buf.writeBytes(bytes);
            buf.writeBoolean(pkt.named);
        }

        public static ClientToServerDialogMessage decode(FriendlyByteBuf buf) {
            int len = buf.readInt();
            byte[] bytes = new byte[len];
            buf.readBytes(bytes);
            String msg = new String(bytes, StandardCharsets.UTF_8);
            boolean named = buf.readBoolean();
            return new ClientToServerDialogMessage(msg, named);
        }

        public static void handle(ClientToServerDialogMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context context = ctx.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null) return;
                if (!sender.hasPermissions(1)) return;

                String outMsg;
                if (pkt.named) {
                    String name = playerNames.get(sender.getUUID());
                    if (name == null || name.trim().isEmpty()) name = sender.getName().getString();
                    outMsg = name + ": " + pkt.message;
                } else {
                    outMsg = pkt.message;
                }

                outMsg = convertColorCodes(outMsg);

                long startMillis = System.currentTimeMillis();
                ServerToClientDialogMessage out = new ServerToClientDialogMessage(outMsg, sender.getUUID(), sender.position().x, sender.position().y, sender.position().z, startMillis);
                double radius = 20.0;
                MinecraftServer server = sender.getServer();
                if (server == null) return;
                List<ServerPlayer> players = server.getPlayerList().getPlayers();
                if (players == null) return;
                for (ServerPlayer target : players) {
                    if (target.distanceToSqr(sender) <= radius * radius && CHANNEL != null) {
                        CHANNEL.send(PacketDistributor.PLAYER.with(() -> target), out);
                    }
                }
            });
            context.setPacketHandled(true);
        }
    }

    public static class ServerToClientDialogMessage {
        public final String message;
        public final UUID senderUuid;
        public final double x, y, z;
        public final long startMillis;

        public ServerToClientDialogMessage(String message, UUID senderUuid, double x, double y, double z, long startMillis) {
            this.message = message;
            this.senderUuid = senderUuid;
            this.x = x;
            this.y = y;
            this.z = z;
            this.startMillis = startMillis;
        }

        public static void encode(ServerToClientDialogMessage pkt, FriendlyByteBuf buf) {
            byte[] bytes = pkt.message.getBytes(StandardCharsets.UTF_8);
            buf.writeInt(bytes.length);
            buf.writeBytes(bytes);
            buf.writeLong(pkt.senderUuid.getMostSignificantBits());
            buf.writeLong(pkt.senderUuid.getLeastSignificantBits());
            buf.writeDouble(pkt.x);
            buf.writeDouble(pkt.y);
            buf.writeDouble(pkt.z);
            buf.writeLong(pkt.startMillis);
        }

        public static ServerToClientDialogMessage decode(FriendlyByteBuf buf) {
            int len = buf.readInt();
            byte[] bytes = new byte[len];
            buf.readBytes(bytes);
            String msg = new String(bytes, StandardCharsets.UTF_8);
            long msb = buf.readLong();
            long lsb = buf.readLong();
            UUID uuid = new UUID(msb, lsb);
            double x = buf.readDouble();
            double y = buf.readDouble();
            double z = buf.readDouble();
            long start = buf.readLong();
            return new ServerToClientDialogMessage(msg, uuid, x, y, z, start);
        }

        public static void handle(ServerToClientDialogMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context context = ctx.get();
            context.enqueueWork(() -> ClientDialogManager.addRemoteMessage(pkt));
            context.setPacketHandled(true);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class ClientDialogManager {
        private static final long DISPLAY_DURATION_MS = 15000L;
        private static final long FADE_MS = 800L;
        private static final int MAX_HISTORY = 20;
        private static final Map<String, ActiveMessage> active = new ConcurrentHashMap<>();
        private static final Random RANDOM = new Random();

        public static void noop() {}

        public static void addRemoteMessage(ServerToClientDialogMessage pkt) {
            if (pkt.message == null) return;
            String trimmed = pkt.message.trim();
            if (trimmed.isEmpty()) return;

            Component comp = Component.literal(trimmed);

            String key = pkt.senderUuid + "_" + pkt.startMillis;
            long localStart = System.currentTimeMillis();
            ActiveMessage m = new ActiveMessage(pkt.senderUuid, comp, localStart, DISPLAY_DURATION_MS);

            for (int i = 0; i < 25; i++) m.particles.add(new Particle());
            active.put(key, m);

            if (active.size() > MAX_HISTORY) {
                String oldestKey = null;
                long oldest = Long.MAX_VALUE;
                for (Map.Entry<String, ActiveMessage> e : active.entrySet()) {
                    if (e.getValue().startMillis < oldest) {
                        oldest = e.getValue().startMillis;
                        oldestKey = e.getKey();
                    }
                }
                if (oldestKey != null) active.remove(oldestKey);
            }
        }

        public static void onClientChat(ClientChatEvent event) {
            String m = event.getMessage();
            if (m == null) return;

            if (m.startsWith("%!")) {
                String after = m.substring(2).trim();
                event.setCanceled(true);
                if (after.isEmpty()) return;
                if (CHANNEL != null) CHANNEL.sendToServer(new ClientToServerDialogMessage(after, true));
            } else if (m.startsWith("%")) {
                String after = m.substring(1).trim();
                event.setCanceled(true);
                if (after.isEmpty()) return;
                if (CHANNEL != null) CHANNEL.sendToServer(new ClientToServerDialogMessage(after, false));
            }
        }

        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            long now = System.currentTimeMillis();
            List<String> toRemove = new ArrayList<>();
            for (Map.Entry<String, ActiveMessage> e : active.entrySet()) {
                ActiveMessage m = e.getValue();
                if (now - m.startMillis > m.duration + FADE_MS) toRemove.add(e.getKey());
                for (Particle p : m.particles) p.tick();
            }
            for (String k : toRemove) active.remove(k);
        }

        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            if (event.getEntity() instanceof LocalPlayer) active.clear();
        }

        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            if (event.getEntity() instanceof LocalPlayer) active.clear();
        }

        public static void onRenderGui(RenderGuiOverlayEvent.Post event) {
            GuiGraphics gui = event.getGuiGraphics();
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return;
            Font font = mc.font;
            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();
            int baseY = screenH - 70;

            List<ActiveMessage> list = new ArrayList<>(active.values());
            list.sort(Comparator.comparingLong(a -> a.startMillis));
            if (list.isEmpty()) return;

            int maxLines = 3;
            int linesToRender = Math.min(maxLines, list.size());
            int lineHeight = font.lineHeight + 10;
            int startY = baseY - (lineHeight * (linesToRender - 1));
            long now = System.currentTimeMillis();

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            int rendered = 0;
            for (int i = Math.max(0, list.size() - linesToRender); i < list.size(); i++) {
                ActiveMessage m = list.get(i);
                long age = now - m.startMillis;
                if (age < 0) age = 0;
                if (age > m.duration + FADE_MS) continue;

                float alpha;
                if (age < FADE_MS) alpha = (float) age / FADE_MS;
                else if (age > m.duration) alpha = 1f - Math.min(1f, (float) (age - m.duration) / FADE_MS);
                else alpha = 1f;

                int textWidth = font.width(m.text.getString());
                int paddingX = 12;
                int paddingY = 6;
                int boxWidth = textWidth + paddingX * 2;
                int boxHeight = font.lineHeight + paddingY * 2;
                int centerX = screenW / 2 - boxWidth / 2;
                int yBase = startY + rendered * (boxHeight + 4);

                double period = 3000.0;
                double phase = ((m.startMillis % 10000L) / 10000.0) * Math.PI * 2.0 + rendered;
                int ampX = 6;
                int ampY = 4;
                int floatX = (int) (Math.sin((now / period) + phase) * ampX);
                int floatY = (int) (Math.cos((now / period) + phase) * ampY);

                int x = centerX + floatX;
                int y = yBase + floatY;

                for (Particle p : m.particles) {
                    float px = x + boxWidth / 2f + p.x();
                    float py = y + boxHeight / 2f + p.y();
                    int pa = (int)(alpha * 255 * p.alphaFactor());
                    gui.fill((int)px, (int)py, (int)px + 1, (int)py + 1, (pa << 24) | 0xFFFFFF);
                }

                int a = (int)(alpha * 255);
                int gradTop = (a << 24) | 0x1A1A1A;
                int gradBot = (a << 24) | 0x000000;
                gui.fillGradient(x, y, x + boxWidth, y + boxHeight, gradTop, gradBot);

                gui.fill(x - 2, y - 2, x + boxWidth + 2, y - 1, (a << 24) | 0xFFFFFF);
                gui.fill(x - 2, y + boxHeight + 1, x + boxWidth + 2, y + boxHeight + 2, (a << 24) | 0xFFFFFF);
                gui.fill(x - 1, y - 1, x + boxWidth + 1, y + 1, (a << 24) | 0x404040);

                gui.drawString(font, m.text, screenW / 2 - textWidth / 2 + floatX, y + paddingY, (a << 24) | 0xFFFFFF, false);

                rendered++;
            }
            RenderSystem.disableBlend();
        }

        private static class ActiveMessage {
            public final UUID sender;
            public final Component text;
            public final long startMillis;
            public final long duration;
            public final List<Particle> particles = new ArrayList<>();

            public ActiveMessage(UUID sender, Component text, long startMillis, long duration) {
                this.sender = sender;
                this.text = text;
                this.startMillis = startMillis;
                this.duration = duration;
            }
        }

        private static class Particle {
            private float angle = RANDOM.nextFloat() * 360f;
            private float radius = 20f + RANDOM.nextFloat() * 10f;
            private float speed = 0.5f + RANDOM.nextFloat() * 0.5f;
            private float phase = RANDOM.nextFloat() * 360f;

            public void tick() {
                angle += speed;
                if (angle > 360f) angle -= 360f;
            }

            public float x() {
                return (float)(Math.cos(Math.toRadians(angle + phase)) * radius * 0.7f);
            }

            public float y() {
                return (float)(Math.sin(Math.toRadians(angle + phase)) * radius * 0.4f);
            }

            public float alphaFactor() {
                return 0.5f + 0.5f * (float)Math.sin(Math.toRadians(angle + phase));
            }
        }
    }

    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ServerChatInterceptor {
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void onServerChat(ServerChatEvent event) {
            Component comp = event.getMessage();
            String msg = comp == null ? "" : comp.getString();
            if (!msg.startsWith("%") && !msg.startsWith("%!")) return;
            Player p = event.getPlayer();
            if (!(p instanceof ServerPlayer sender)) return;
            if (!sender.hasPermissions(1)) return;
            boolean named = msg.startsWith("%!");
            String after = msg.substring(named ? 2 : 1).trim();
            event.setCanceled(true);
            if (after.isEmpty()) return;
            String outMsg;
            if (named) {
                String name = playerNames.get(sender.getUUID());
                if (name == null || name.trim().isEmpty()) name = sender.getName().getString();
                outMsg = name + ": " + after;
            } else outMsg = after;
            outMsg = convertColorCodes(outMsg);
            long start = System.currentTimeMillis();
            ServerToClientDialogMessage out = new ServerToClientDialogMessage(outMsg, sender.getUUID(), sender.position().x, sender.position().y, sender.position().z, start);
            double radius = 20.0;
            MinecraftServer server = sender.getServer();
            if (server == null) return;
            List<ServerPlayer> players = server.getPlayerList().getPlayers();
            if (players == null) return;
            for (ServerPlayer target : players) {
                if (target.distanceToSqr(sender) <= radius * radius && CHANNEL != null) {
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> target), out);
                }
            }
        }
    }

    private static String convertColorCodes(String s) {
        if (s == null) return null;
        return s.replace('&', '\u00A7');
    }
}
