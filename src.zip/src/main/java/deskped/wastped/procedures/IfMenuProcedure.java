package deskped.wastped.procedures;

import deskped.wastped.network.WastpedModVariables;

public class IfMenuProcedure {
	public static boolean execute() {
		if (WastpedModVariables.custommenu == true) {
			return true;
		}
		return false;
	}
}