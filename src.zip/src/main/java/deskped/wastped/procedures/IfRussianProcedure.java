package deskped.wastped.procedures;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.Minecraft;

@OnlyIn(Dist.CLIENT)
public class IfRussianProcedure {
	public static boolean execute() {
		try {
			String lang = Minecraft.getInstance().getLanguageManager().getSelected();
			if (lang == null) return false;
			return lang.equalsIgnoreCase("ru_ru") || lang.toLowerCase().startsWith("ru");
		} catch (Exception e) {
			return false;
		}
	}
}
