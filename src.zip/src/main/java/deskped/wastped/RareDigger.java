package deskped.wastped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "wastped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RareDigger {

	private static final float CHANCE = 0.01f;

	@SubscribeEvent
	public static void onBreak(BlockEvent.BreakEvent e) {
		if (e.getLevel().isClientSide()) return;

		Player p = e.getPlayer();
		if (p == null || p.isCreative()) return;

		Level w = (Level) e.getLevel();
		BlockPos pos = e.getPos();
		RandomSource r = w.getRandom();

		boolean gave = false;

		if (p.hasEffect(MobEffects.LUCK)) {
			int pick = r.nextInt(3);
			ItemStack stack = pick == 0 ? new ItemStack(Items.ANCIENT_DEBRIS) : pick == 1 ? new ItemStack(Items.GOLD_NUGGET) : new ItemStack(Items.DIAMOND);
			w.addFreshEntity(new ItemEntity(w, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, stack));
			gave = true;
		} else if (r.nextFloat() < CHANCE) {
			w.addFreshEntity(new ItemEntity(w, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.ANCIENT_DEBRIS)));
			gave = true;
		}

		if (gave) ClientOverlay.trigger();
	}

	@OnlyIn(Dist.CLIENT)
	public static class ClientOverlay {

		private static int ticks;
		private static final int TOTAL = 40;

		private static float x;
		private static float y0;

		static void trigger() {
			Minecraft mc = Minecraft.getInstance();
			if (mc == null) return;

			x = mc.getWindow().getGuiScaledWidth() * 0.5f;
			y0 = mc.getWindow().getGuiScaledHeight() * 0.5f;

			ticks = TOTAL;
		}

		@SubscribeEvent
		public static void tick(TickEvent.ClientTickEvent e) {
			if (e.phase == TickEvent.Phase.END && ticks > 0) ticks--;
		}

		@SubscribeEvent
		public static void render(RenderGuiOverlayEvent.Post e) {
			if (ticks <= 0) return;

			Minecraft mc = Minecraft.getInstance();
			if (mc == null) return;

			float p = 1f - ticks / (float) TOTAL;

			float start = y0 + 18f;
			float mid = y0 + 6f;
			float end = y0 - 14f;

			float y;
			float a;

			if (p < 0.5f) {
				float t = p * 2f;
				y = start + (mid - start) * t * t;
				a = t;
			} else {
				float t = (p - 0.5f) * 2f;
				y = mid + (end - mid) * t;
				a = 1f - t;
			}

			int alpha = (int)(a * 160f);
			int color = (alpha << 24) | 0xFFD700;

			GuiGraphics g = e.getGuiGraphics();

			g.drawCenteredString(mc.font, Component.translatable("block.wastped.rare"), (int)x, (int)y, color);
		}
	}
}
