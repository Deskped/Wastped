import os

# Короч этот файл temp в каком то смысле, он нужен чтобы облегчить мне работу.
folder = os.getcwd()

files = [f for f in os.listdir(folder) if f.endswith(".png")]

files.sort()

for f in files:
    name, ext = os.path.splitext(f)
    new_name = name.replace(".", "_") + ext
    if f != new_name:
        os.rename(os.path.join(folder, f), os.path.join(folder, new_name))
        print(f"{f} -> {new_name}")
