import os
from PIL import Image

folder = os.path.dirname(os.path.abspath(__file__))

def resize_and_optimize(image, target_width=1280, target_height=720):
    original_width, original_height = image.size
    ratio = min(target_width / original_width, target_height / original_height)
    new_size = (int(original_width * ratio), int(original_height * ratio))
    resized = image.resize(new_size, Image.LANCZOS)
    
    final_image = Image.new("RGBA", (target_width, target_height), (0, 0, 0, 255))
    paste_position = ((target_width - new_size[0]) // 2, (target_height - new_size[1]) // 2)
    final_image.paste(resized, paste_position)
    
    return final_image.convert("P", palette=Image.ADAPTIVE)

for filename in os.listdir(folder):
    if filename.lower().endswith(".png"):
        filepath = os.path.join(folder, filename)
        with Image.open(filepath) as img:
            optimized_img = resize_and_optimize(img)
            optimized_img.save(filepath, optimize=True)
